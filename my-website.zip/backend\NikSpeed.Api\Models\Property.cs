using System.ComponentModel.DataAnnotations;

namespace NikSpeed.Api.Models;

public record Property(
    Guid Id,
    string Title,
    string Type,
    string Location,
    int Price,
    string Currency,
    int Bedrooms,
    int Bathrooms,
    int Area,
    string AreaUnit,
    string ImageUrl,
    bool Featured,
    string Description,
    string AgentName,
    string AgentPhone,
    string VideoUrl = "",
    string[]? ImageUrls = null,
    string[]? VideoUrls = null);

public record CreatePropertyRequest(
    string Title, string Type, string Location, int Price, string Currency,
    int Bedrooms, int Bathrooms, int Area, string AreaUnit, string ImageUrl,
    string Description, string AgentName, string AgentPhone, string VideoUrl = "");

public record CheckoutRequest(
    [property: Required, StringLength(40, MinimumLength = 1)] string PlanId,
    [property: Required, StringLength(120, MinimumLength = 1)] string AdvertiserName,
    [property: Required, EmailAddress, StringLength(254)] string Email,
    [property: RegularExpression("^(card|mobile_money)$")] string PaymentMethod = "card");

public record EnquiryRequest(
    [property: Required] Guid PropertyId,
    [property: Required, StringLength(120, MinimumLength = 1)] string Name,
    [property: Required, EmailAddress, StringLength(254)] string Email,
    [property: StringLength(32)] string Phone,
    [property: Required, StringLength(2000, MinimumLength = 1)] string Message);

public record ListingPlan(string Id, string Name, int Price, int Listings, bool Featured)
{
    public static readonly ListingPlan[] All =
    [
        new("starter", "Starter", 25000, 1, false),
        new("professional", "Professional", 75000, 5, true),
        new("agency", "Agency", 180000, 15, true)
    ];
}
