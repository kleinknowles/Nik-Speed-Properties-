using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using NikSpeed.Api.Data;
using NikSpeed.Api.Data.Entities;

namespace NikSpeed.Api.Tests;

public class MarketplaceDbContextTests
{
    [Fact]
    public async Task SaveChanges_EnforcesUniqueUserEmailIndex()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<MarketplaceDbContext>().UseSqlite(connection).Options;
        await using var database = new MarketplaceDbContext(options);
        await database.Database.EnsureCreatedAsync();
        database.Users.Add(new User { Name = "First", Email = "same@example.test", PasswordHash = "hash-1" });
        await database.SaveChangesAsync();
        database.Users.Add(new User { Name = "Second", Email = "same@example.test", PasswordHash = "hash-2" });

        await Assert.ThrowsAsync<DbUpdateException>(() => database.SaveChangesAsync());
    }

    [Fact]
    public async Task SaveChanges_EnforcesUniquePaymentProviderReference()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<MarketplaceDbContext>().UseSqlite(connection).Options;
        await using var database = new MarketplaceDbContext(options);
        await database.Database.EnsureCreatedAsync();
        database.Payments.Add(new PaymentTransaction { ProviderReference = "ns-same-reference", PlanId = "starter", Amount = 25000 });
        await database.SaveChangesAsync();
        database.Payments.Add(new PaymentTransaction { ProviderReference = "ns-same-reference", PlanId = "starter", Amount = 25000 });

        await Assert.ThrowsAsync<DbUpdateException>(() => database.SaveChangesAsync());
    }
}
