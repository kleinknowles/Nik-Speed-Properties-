
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ContactAssistant } from "../components/ContactAssistant";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("ContactAssistant", () => {
  it("opens the message form from the assistant welcome screen", () => {
    render(<ContactAssistant />);

    fireEvent.click(
      screen.getByRole("button", { name: "Open website assistant" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: /start a conversation/i })
    );

    expect(screen.getByRole("textbox", { name: "Name Name" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /send message/i })).toBeInTheDocument();
  });

  it("encodes submitted contact details into a mailto link", () => {
    const assign = vi.fn();

    vi.stubGlobal("location", {
      href: "http://localhost/",
      assign,
    });

    render(<ContactAssistant />);

    fireEvent.click(
      screen.getByRole("button", { name: "Open website assistant" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: /start a conversation/i })
    );

    fireEvent.change(screen.getByLabelText("Name"), {
      target: { value: "Alex Example" },
    });

    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "alex@example.test" },
    });

    fireEvent.change(screen.getByLabelText("Phone"), {
      target: { value: "700123456" },
    });

    fireEvent.change(screen.getByLabelText("Message"), {
      target: { value: "Interested in a home" },
    });

    fireEvent.submit(
      screen.getByRole("button", { name: /send message/i }).closest("form")!
    );

    expect(window.location.href).toContain("mailto:nikspeedgobal@gmail.com");

    expect(window.location.href).toContain(
      encodeURIComponent("Website enquiry from Alex Example")
    );

    expect(screen.getByRole("status")).toHaveTextContent(
      "Opening your email app"
    );
  });
});
