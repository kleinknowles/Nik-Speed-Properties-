using System.Net;
using System.Text;

namespace NikSpeed.Api.Tests.Fakes;

internal sealed class StubHttpMessageHandler(params string[] jsonResponses) : HttpMessageHandler
{
    private readonly Queue<string> responses = new(jsonResponses);
    public List<HttpRequestMessage> Requests { get; } = [];

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        Requests.Add(request);
        var json = responses.Dequeue();
        return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = new StringContent(json, Encoding.UTF8, "application/json")
        });
    }
}
