using Microsoft.Extensions.Configuration;
using NikSpeed.Api.Models;
using NikSpeed.Api.Services;
using NikSpeed.Api.Tests.Fakes;

namespace NikSpeed.Api.Tests;

public class PesapalPaymentServiceTests
{
    [Fact]
    public async Task CreateCheckout_UsesFakeProviderAndReturnsCheckoutUrl()
    {
        var handler = new StubHttpMessageHandler("""{"token":"test-token"}""", """{"status":"200","redirect_url":"https://checkout.example.test/order"}""");
        var configuration = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Pesapal:ConsumerKey"] = "offline-key",
            ["Pesapal:ConsumerSecret"] = "offline-secret",
            ["Pesapal:NotificationId"] = "ca44e521-16c1-44cd-b951-29fc00161239",
            ["Pesapal:BaseUrl"] = "https://pesapal.example.test",
            ["Pesapal:CallbackUrl"] = "http://localhost/payment/complete"
        }).Build();
        var service = new PesapalPaymentService(new HttpClient(handler), configuration);

        var result = await service.CreateCheckout(ListingPlan.All[0], new CheckoutRequest("starter", "Alex Example", "alex@example.test"), "ns-offline-order");

        Assert.Equal("pending", result.Status);
        Assert.Equal("https://checkout.example.test/order", result.PaymentLink);
        Assert.Equal(2, handler.Requests.Count);
        Assert.Equal("Bearer test-token", handler.Requests[1].Headers.Authorization?.ToString());
    }

    [Fact]
    public async Task CreateCheckout_WithoutCredentialsDoesNotCallProvider()
    {
        var handler = new StubHttpMessageHandler();
        var service = new PesapalPaymentService(new HttpClient(handler), new ConfigurationBuilder().Build());

        var result = await service.CreateCheckout(ListingPlan.All[0], new CheckoutRequest("starter", "Alex Example", "alex@example.test"), "ns-offline-order");

        Assert.Equal("configuration_required", result.Status);
        Assert.Empty(handler.Requests);
    }
}
