import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import Home from "../app/page";

vi.mock("../components/SiteShell", () => ({
  SiteShell: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));
vi.mock("../components/LocationMap", () => ({
  LocationLink: ({ location }: { location: string }) => <span>{location}</span>,
}));
vi.mock("next/link", () => ({
  default: ({ href, children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => <a href={href} {...props}>{children}</a>,
}));

describe("marketplace search and enquiry", () => {
  beforeEach(() => {
    localStorage.clear();
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.startsWith("/api/enquiries")) return new Response(JSON.stringify({ message: "Enquiry received" }), { status: 200 });
      if (url.includes("Kololo")) return new Response(JSON.stringify([]), { status: 200 });
      return new Response(JSON.stringify([]), { status: 200 });
    }));
  });

  it("submits search filters to the property API", async () => {
    render(<Home />);
    fireEvent.change(screen.getByPlaceholderText("Location e.g. Kololo"), { target: { value: "Kololo" } });
    fireEvent.click(screen.getByRole("button", { name: /search properties/i }));
    await waitFor(() => expect(fetch).toHaveBeenCalledWith(expect.stringContaining("location=Kololo")));
    await waitFor(() => expect(screen.getByText("0", { selector: ".stats strong" })).toBeInTheDocument());
  });

  it("posts an enquiry and displays its confirmation", async () => {
    render(<Home />);
    fireEvent.click(screen.getAllByRole("button", { name: "View details →" })[0]);
    fireEvent.change(screen.getByPlaceholderText("Your name"), { target: { value: "Alex Example" } });
    fireEvent.change(screen.getByPlaceholderText("Email address"), { target: { value: "alex@example.test" } });
    fireEvent.click(screen.getByRole("button", { name: "Send enquiry" }));
    await waitFor(() => expect(screen.getByText("Your enquiry is on its way to the advertiser.")).toBeInTheDocument());
    expect(fetch).toHaveBeenCalledWith("/api/enquiries", expect.objectContaining({ method: "POST" }));
  });
});
