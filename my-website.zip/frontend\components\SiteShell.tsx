"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode } from "react";
import { useEffect, useState } from "react";

export function Header({ onSignIn, onRegister }: { onSignIn?: () => void; onRegister?: () => void }) {
  const [savedCount, setSavedCount] = useState(0);
  const pathname = usePathname();

  const pageTheme = pathname === "/" ? "home"
    : pathname.startsWith("/listings/") ? "property"
    : pathname.startsWith("/listings") ? "listings"
    : pathname.startsWith("/saved") ? "saved"
    : pathname.startsWith("/advertise") ? "advertise"
    : pathname.startsWith("/about") ? "about"
    : pathname.startsWith("/contact") ? "contact"
    : pathname.startsWith("/dashboard") ? "dashboard"
    : pathname.startsWith("/payment") ? "payment"
    : pathname.startsWith("/terms") ? "terms"
    : pathname.startsWith("/privacy") ? "privacy" : "home";

  useEffect(() => {
    const updateSavedCount = () => {
      try {
        const saved = JSON.parse(localStorage.getItem("nikspeed-saved") || "[]");
        setSavedCount(Array.isArray(saved) ? saved.length : 0);
      } catch { setSavedCount(0); }
    };
    updateSavedCount();
    window.addEventListener("storage", updateSavedCount);
    window.addEventListener("nikspeed-saved-change", updateSavedCount);
    return () => {
      window.removeEventListener("storage", updateSavedCount);
      window.removeEventListener("nikspeed-saved-change", updateSavedCount);
    };
  }, []);

  return <header className="site-header" data-page-theme={pageTheme}><Link className="brand" href="/" aria-label="Nik-Speed Properties LLC home"><span className="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48"><path d="M24 4 5 19v24h14V29h10v14h14V19L24 4Z"/><path d="m12 21 12-10 12 10"/><path d="M20 22h8v4h-8z"/></svg></span><span className="brand-name">Nik Speed <em>Properties LLC</em></span></Link><nav className="site-nav" aria-label="Main navigation"><Link href="/listings" aria-current={pageTheme === "listings" ? "page" : undefined}>Browse homes</Link><Link href="/saved" aria-current={pageTheme === "saved" ? "page" : undefined}>Saved homes{savedCount > 0 ? ` (${savedCount})` : ""}</Link><Link href="/advertise" aria-current={pageTheme === "advertise" ? "page" : undefined}>Advertise</Link><Link href="/about" aria-current={pageTheme === "about" ? "page" : undefined}>About us</Link><Link href="/contact" aria-current={pageTheme === "contact" ? "page" : undefined}>Contact</Link><Link href="/dashboard" aria-current={pageTheme === "dashboard" ? "page" : undefined}>Dashboard</Link><a className="header-facebook" href="https://www.facebook.com/klein.knowles/" target="_blank" rel="noreferrer" aria-label="Follow Nik-Speed on Facebook"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 8h3V4h-3a5 5 0 0 0-5 5v3H6v4h3v4h4v-4h3l1-4h-4V9a1 1 0 0 1 1-1Z"/></svg><span>Follow us</span></a>{onSignIn && <button type="button" className="home-signin" onClick={onSignIn}>Sign in</button>}{onRegister && <button type="button" className="home-register" onClick={onRegister}>Create account</button>}</nav></header>;
}

export function Footer() {
  return <footer><div><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48"><path d="M24 4 5 19v24h14V29h10v14h14V19L24 4Z"/><path d="m12 21 12-10 12 10"/><path d="M20 22h8v4h-8z"/></svg></span><span className="brand-name">Nik Speed <em>Properties LLC</em></span></Link><p>Property decisions, made simpler.</p><div className="footer-device-list" aria-label="Works on your devices"><span aria-hidden="true">▣</span> Phones <span aria-hidden="true">▰</span> Tablets <span aria-hidden="true">▰</span> Desktops</div></div><div className="footer-navigation"><div className="footer-links"><Link href="/contact">Contact</Link><Link href="/about">About</Link><Link href="/terms">Terms</Link><Link href="/privacy">Privacy</Link></div><small className="footer-credit">Designed &amp; Assembled by Nik-Speed I.T Solution &amp; Internet Services</small></div><div className="footer-right"><div className="footer-socials" aria-label="Social media"><a href="https://www.facebook.com/klein.knowles/" aria-label="Facebook" target="_blank" rel="noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 8h3V4h-3a5 5 0 0 0-5 5v3H6v4h3v4h4v-4h3l1-4h-4V9a1 1 0 0 1 1-1Z"/></svg></a><a href="https://www.instagram.com/" aria-label="Instagram" target="_blank" rel="noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="18" cy="6" r=".8"/></svg></a><a href="https://www.linkedin.com/" aria-label="LinkedIn" target="_blank" rel="noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 9v10M5 5v.1M10 19v-6a4 4 0 0 1 8 0v6M10 9v10"/></svg></a><a href="https://www.youtube.com/" aria-label="YouTube" target="_blank" rel="noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="4"/><path d="m10 9 5 3-5 3z"/></svg></a></div><p>© 2026 Nik-Speed Properties LLC</p></div></footer>;
}

export function SiteShell({ children, onSignIn, onRegister }: { children: ReactNode; onSignIn?: () => void; onRegister?: () => void }) { return <><Header onSignIn={onSignIn} onRegister={onRegister} />{children}<Footer /></>; }
