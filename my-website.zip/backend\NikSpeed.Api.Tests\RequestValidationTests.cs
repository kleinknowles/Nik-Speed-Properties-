using System.Net;
using System.Net.Http.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.IdentityModel.Tokens;

namespace NikSpeed.Api.Tests;

public class RequestValidationTests
{
    [Fact]
    public async Task MalformedCheckoutRequestReturnsBadRequestWithFieldErrors()
    {
        using var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.UseEnvironment("Development");
            builder.ConfigureAppConfiguration((_, configuration) => configuration.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Key"] = "test-signing-key-with-at-least-32-characters",
                ["ConnectionStrings:Marketplace"] = "Data Source=:memory:"
            }));
            builder.ConfigureTestServices(services => services.Configure<FormOptions>(options => options.MultipartBodyLengthLimit = 1024 * 1024));
        });
        using var client = factory.CreateClient();
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("test-signing-key-with-at-least-32-characters"));
        var token = new JwtSecurityTokenHandler().WriteToken(new JwtSecurityToken(
            issuer: "NikSpeed.Api",
            audience: "NikSpeed.Web",
            claims: [new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())],
            expires: DateTime.UtcNow.AddMinutes(5),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)));
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var response = await client.PostAsJsonAsync("/api/payments/checkout", new { planId = "", advertiserName = "", email = "not-an-email" });
        var body = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Contains("Email", body, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("PlanId", body, StringComparison.OrdinalIgnoreCase);
    }
}
